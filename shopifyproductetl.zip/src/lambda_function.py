import os, json, time, datetime, requests, uuid
import boto3

SHOP = os.environ['SHOP_DOMAIN']
API_TOKEN = os.environ['SHOPIFY_TOKEN']
S3_BUCKET = os.environ['S3_BUCKET']
S3_PREFIX = 'shopify/products'

HEADERS = {'X-Shopify-Access-Token': API_TOKEN, 'Content-Type': 'application/json'}
s3 = boto3.client('s3')

def fetch_all_products(limit=50):
    url = f'https://{SHOP}/admin/api/2025-10/products.json?limit={limit}'
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    return r.json().get('products', [])

def write_ndjson(products):
    date = datetime.datetime.utcnow().strftime('%Y-%m-%d')
    key = f'{S3_PREFIX}/date={date}/products-{uuid.uuid4()}.ndjson'
    
    # Add the date field to each product
    lines = []
    for p in products:
        p['date'] = date
        lines.append(json.dumps(p, default=str))
    
    body = '\n'.join(lines)
    s3.put_object(Bucket=S3_BUCKET, Key=key, Body=body.encode('utf-8'))
    print(f"Saved {len(products)} products to s3://{S3_BUCKET}/{key}")

def lambda_handler(event, context):
    print("Fetching products from Shopify...")
    products = fetch_all_products(limit=50)
    print(f"Fetched {len(products)} products")
    write_ndjson(products)
    return {"status": "success", "count": len(products)}
